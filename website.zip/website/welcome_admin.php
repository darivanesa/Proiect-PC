<?php 

session_start();

if (isset($_SESSION['adminName'])) {
   echo "<p>HEI". $_SESSION['adminName']. "</p>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
    <title>Welcome</title>
</head>
<body>
<div style="background-image: url('bgd.gif');background-repeat: no-repeat;
    background-attachment: fixed;  
    background-size: cover;">
<div class="sidenav">
  <a href="logout.php">Logout</a>
  <a href="welcome.php">Home</a>
  <button class="dropdown-btn">Menu
    <i class="fa fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="task.php">Task</a>
    <a href="skill.php">Skill</a>
    <a href="teams.php">Teams</a>
    <a href="deadline.php">Deadline</a>
  </div>
</div>
</div>
</div>
</div>
<?php echo "<h1 align=top size=40px><strong>Welcome " . $_SESSION['adminName'] . "</h1></strong>"; ?>
 
<script>
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>
</body>
</html>
  