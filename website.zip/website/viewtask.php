<?php
include 'config.php';
if(!$conn){
die("Error: Cannot connect to the database");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      td {
        border: 1px;
        border-style: solid;
        border-color: #dddddd;
        text-align: center;
        padding: 3px;
      }
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js">
    </script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer>
    </script>
    <title>Task List
    </title>
  </head>
  <body style="background-color:#E3ECF8;">
    <div style="height:70px; background-color:white ;  border-bottom: 1px solid grey;">
      <div style=" position:relative; left:5px; top:2px;top:20px">
        <p style='margin-left:260px;font-family: "Calibri",sans-serif;font-size:25px'>Task Dispatcher
        </p>
      </div>
    </div>
    <div style=" position:relative; left:5px; top:2px;top:20px">
      <p style='margin-left:260px;font-family: "Calibri",sans-serif;font-size:35px'>View Tasks
      </p>
    </div>
    <div style="position:relative; left:210px; top:-10px;width:900px;border: 15px grey;
                padding: 50px;background-color:transparent;border-radius:10px;box-sizing:border-box;height:150px">
      <form action="" method="post">
        <table>
          <tr>
            <th>
              <input type="text" placeholder="Enter Task ID" value style="-moz-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                                          -webkit-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                                          box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                                          padding:10px;height: 40px;border-radius:10px;border-style: solid transparent ; background-color: white;border-color:#D0D0D;border-width: thin;font-weight: lighter;" name="taskName" id="taskName">
            </th>
            <th> 
              <input type="text" placeholder="Teams" style="-moz-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                            -webkit-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                            box-shadow: 1px 2px 3px rgba(0,0,0,.5);padding:10px;margin-left:20px;height: 40px;border-radius:10px;border-style: solid transparent; background-color: white;border-color:#D0D0D;font-weight: lighter;border-width: thin" name="teams" id="teams">
            </th>
            <th>
              <select name="status" id="status" style="-moz-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                       -webkit-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                       box-shadow: 1px 2px 3px rgba(0,0,0,.5);padding:10px;margin-left:20px;height: 40px;border-radius:10px;border-style: solid transparent; background-color: white;border-color:#D0D0D;font-weight: lighter;">
                <option value="" disabled selected>Select status
                </option>
                <option value="investigate">Investigate
                </option>
                <option value="progress">In Progress
                </option>
                <option value="solvedProposed">Solved Proposed
                </option>
                <option value="solvedConfirmed">Solved Confirmed
                </option>
              </select>
            </th>
            <th>
              <select name="departments" id="department" style="-moz-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                                -webkit-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                                box-shadow: 1px 2px 3px rgba(0,0,0,.5);padding:10px;margin-left:20px;height: 40px;border-radius:10px;border-style: solid transparent ; background-color: white;border-color:#D0D0D; border-width: thin;font-weight: lighter; ">
                <option value="" disabled selected>Select a department
                </option>
                <option value="administrare">Administrare
                </option>
                <option value="support">Support
                </option>
                <option value="dev">Dev
                </option>
              </select>
            </th>
            <th> 
              <select name="priority" id="priority" style="-moz-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                           -webkit-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
                                                           box-shadow: 1px 2px 3px rgba(0,0,0,.5);padding:10px;margin-left:20px;height: 40px;border-radius:10px;border-style: solid transparent ; background-color: white;border-color:#D0D0D; border-width: thin;font-weight: lighter;">
                <option value="" disabled selected>Select priority
                </option>
                <option value="low">Low
                </option>
                <option value="medium">Medium
                </option>
                <option value="high">High
                </option>
              </select>
              <br>
            </th>
            <th> 
              <input type="submit" name = "filterTasks"style='font-family: "Calibri",sans-serif;background-color:#00559A;color:white;padding: 5px 10px;;border-color:#00559A;
                                                              font-size:20px;border-radius:3px;
                                                              border: none; box-shadow: 2px 2px 2px grey; margin-left:25px
                                                              ' value="Filter tasks">
            </th>
          </tr>
        </table>
      </form>
    </div>
    <div style="width:100%;border: 15px grey;
                padding: 50px;background-color:#transparent;box-sizing:border-box;height:400px; margin-left:5%;margin-top:-120px">
      <div style="width:100%%;border-width: 15px;border-color: grey;
                  padding: 50px;background-color:#EDEDED;box-sizing:border-box;height:900px;margin-top:4%;">
        <table style = "font-family: arial, sans-serif;
                        border-collapse: collapse;
                        width: 100%;margin-left:1.75%; margin-top:-4%;border-width: 1px;border-style: solid; border: none">
          <tp  >
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Task ID:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Task Name:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Skills:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Team:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Employee:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Department:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Priority:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Status:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px;">Deadline:
            </th>
            <th style="​border: 1px; border-style: solid;border-color: #dddddd;
                       text-align: center;
                       padding: 3px">Date:
            </th>
          </tp>
          <?php
            $conn=mysqli_connect("localhost","root","","project_pc");
            // Check connection
            $sql = "SELECT taskID, taskName, skills, team, employee, department, priority, status, deadline, date From tasks";
            //if(isset($_POST['showAll'])){
             // echo "0 resul            ts";
              $result = $conn->query($sql);
              if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . $row["taskID"]. "</td><td>" . $row["taskName"] . "</td><td>" . $row["skills"].
                  "</td><td>" . $row["team"] . "</td><td>" . $row["employee"]. "</td><td>" . $row["department"] . 
                  "</td><td>" . $row["priority"] . "</td><td>" . $row["status"] . "</td><td>" . $row["deadline"] . "</td><td>" . $row["date"]."</td></tr>"        ;
                }
                echo "</table>";
              } else { echo "0 results"; }
            //}
            $conn->close();
            ?>
        </table>
      </div>
    </div>
    <div class="sidenav">
      <a href="logout.php">Logout
      </a>
      <a href="welcome.php">Home
      </a>
      <button class="dropdown-btn">Menu
        <i class="fa fa-caret-down">
        </i>
      </button>
      <div class="dropdown-container">
        <a href="task.php">Task
        </a>
        <a href="skill.php">Skill
        </a>
        <a href="teams.php">Teams
        </a>
        <a href="deadline.php">Deadline
        </a>
      </div>
    </div>
    <script>
      var dropdown = document.getElementsByClassName("dropdown-btn");
      var i;
      for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
          this.classList.toggle("active");
          var dropdownContent = this.nextElementSibling;
          if (dropdownContent.style.display === "block") {
            dropdownContent.style.display = "none";
          }
          else {
            dropdownContent.style.display = "block";
          }
        }
                                    );
      }
    </script>
  </body>
</html>
