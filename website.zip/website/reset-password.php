<?php 

include 'config.php';
?>
<body>
    <div class="container">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;text-align:center;font-family:sans-serif">Reseteaza parola</p>
            <p>Un email va fi trimis cu instructiuni despre cum sa va schimbati parola.</p>
        <form action ="reset-request.php" method="post">
            <input type="text" name="email" placeholder="Adaugati adresa de email">
            <button type="submit" name="reset-request-submit">Trimite parola noua</button>
        </form>
        <?php
        if (isset($_GET["reset"])){
            if($_GET["reset"] == "succes"){
                echo '<p class="signupacces">Verificati email!</p>';
            }
        
        }
        ?>
    </div>
</body>