

<!DOCTYPE html>
<html style="height:100vh; min-height: 100%s" lang="en">
	<head>





		<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title>Task List</title>

    <style>

.task-container{
width:1200px;
    background-color:transparent;
    height:900px;
    margin-top:45px;
    margin-left:180px;
    border-radius:10px
}


.task-container .info-container{


    position:relative;
     top:20px;
     left:40px;
     width:500px;
     background-color:transparent;
     height:300px;
     font-size:20px;
}


.comment-box{
position:relative;
left:70px;
top:-100px;



}


.comment-table{
position:relative;
left:100px;
top:200px;



}


.task-container .info-container .descrip {
    position:relative;
left:600px;
top:-115px;




}



.titlu {
    box-shadow: 20px 1px 5px 	#E8E8E8;
    height:70px; background-color:#f8f8f8 ;  
    border-bottom: 1px solid 	#E8E8E8;




}



hr {
  border:none;
  border-top:1px ridge grey;
  color:#fff;
  background-color:#fff;
  height:1px;
  width:150%;
  position:relative;

top:-160px;
left: 2px;
}


.task-container .info-container .whatev {
    width:100%;
    font-family: "Calibri",sans-serif;

}

.task-container .info-container .whatev th ,td{
  
    font-family: "Calibri",sans-serif;

}

.task-container .info-container .descrip th,td {
  
  font-family: "Calibri",sans-serif;

}

    </style>



</head>
<body style="background-color:white; height:100vh;  min-height: 100%">
	


<div class= "titlu">
<div style=" position:relative; left:5px; top:2px;top:20px">

<p style='margin-left:220px;font-family: "Calibri",sans-serif;font-size:25px'>Task Dispatcher</p>

</div>
</div>

<div style=" position:relative; left:5px; top:2px;top:20px">

<p style='margin-left:220px;font-family: "Calibri",sans-serif;font-size:35px'>View Tasks</p>
</div>


<div class = "task-container">


<div class ="info-container" >

<table class="whatev">
  <tr >
    <th style = 'font-family: "Calibri",sans-serif;' >Task ID:</th>
    <td>lol</td>
  </tr>
  <tr>
    <th>Task Name</th>
    <td>555 77 854</td>
  </tr>
  <tr>
    <th>Status</th>
    <td>555 77 855</td>
  </tr>
  <tr>
    <th>Deadline</th>
    <td>555 77 855</td>
  </tr>
</table>

<table class="descrip">
<tr>
    <th>Description</th>
    
  </tr>
  <tr>
  <td>555 77 855</td>
  </tr>
  </table>

</div>

<hr></hr>

<!-- 
<div>

<select name="status" id="status" style="position:relative;top:-60px;-moz-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
-webkit-box-shadow: 1px 2px 3px rgba(0,0,0,.5);
box-shadow: 1px 2px 3px rgba(0,0,0,.5);padding:10px;margin-left:20px;height: 40px;border-radius:10px;border-style: solid transparent; background-color: white;border-color:#D0D0D;font-weight: lighter;">
   
   <option value="" disabled selected>Select status</option>
   <option value="open">open</option>
     <option value="inProgress">In Progress</option>
   <option value="solved">Solved</option>
   

</div> -->


    <div class=comment-box>
    <form action="comment.php" method="POST">
        <colgroup>
            <col width="25%" style="vertical-align:top;"/>
            <col width="75%" style="vertical-align:top;"/>
        </colgroup>
        <table>
           
            <tr>
                <td><label for="comment">Comment:</label></td>
             
            </tr>

            <tr>
            <td><textarea name="comment" rows="8" cols="100"></textarea></td>
</tr>
            <tr><td colspan="2"><input type="submit" name="submit" value="Comment"></td></tr>
        </table>
       

</div>


<div class="comment-table">
        <table id="commentTable">
            <colgroup>
                <col width="25%"/>
                <col width="75%"/>
            </colgroup>
            <thead>
                <tr>
                    <th>Name</th>
                    
                </tr>

                <tr>
                <th>Comment</th>
</tr>
            </thead>
            <tbody>
            </table>

            </div>


            




    </div>


     <div class="sidenav" style='background-color:#303030;  font-family: "Calibri",sans-serif;'>
         <h4 style="margin-left:15px;font-size:22px;color:#E8E8E8;  border-bottom: 1px solid #202020;  box-shadow: 20px 1px 5px #202020;">Task Dispatcher</h4>
  <a href="logout.php">Logout</a>
  <a href="welcome.php">Home</a>
  <button class="dropdown-btn">Menu
    <i class="fa fa-caret-down"></i>
  </button>




  <div class="dropdown-container">
    <a href="task.php">Task</a>
    <a href="skill.php">Skill</a>
    <a href="teams.php">Teams</a>
    <a href="deadline.php">Deadline</a>
  </div>
  </div>


</body>
</html>






		



 


