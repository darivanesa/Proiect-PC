<?php 

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['username'])) {
    header("Location: welcome.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);
    isset($_POST['remember']) ? $remember = $_POST['remember'] : $remember = " ";

	$sql = "SELECT * FROM register WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);

	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
        $_SESSION['user_type'] = $row['user_type'];
        if ($_SESSION['user_type'] == 1){
            header("Location: welcome_admin.php");
        }else {
            header("Location: welcome.php");
        }
		
        echo $row['username'];
        
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}

            }
            

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title>Autentificare</title>
</head>
<body>

	<div class="container">
		<form action="" method="POST" class="login-email">
            <form action ="validate-captcha.php" method="post">
            
			<p class="login-text" style="font-size: 2rem; font-weight: 800;text-align:center;font-family:sans-serif">Login</p>
			<div class="input-group">
                <i class="fa fa-envelope icon " ></i>
				<input type="email" autofocus placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
                <i class="fa fa-key icon " ></i>
				<input type="password" autofocus placeholder="Password" id="myInput" name="password" value="<?php echo $_POST['password']; ?>" required>       <span id="toggle_pwd" class="fa fa-fw fa-eye field_icon"></span>
			</div>
            <div class="g-recaptcha" data-sitekey="6LeHJeIaAAAAAGaMhCvbGpNqhSMpZAjbdGouj7Rj"></div>
             
               
			<div class="input-group">
				<button name="submit" class="btn">Login</button>
			</div>

                <br>
            <p align="center" >
                <?php 
                    if(isset($_GET["newpwd"])){
                    if($_GET["newpwd" == "passwordupdated"]){
                        echo '<p class="signupsucces"> Parola a fost resetata!</p>';
                    }
                }
                ?>
                <a href="reset-password.php" class="form__link">Ai uitat parola?</a>
            </p>

			<p class="login-register-text">Nu ai deja un cont? <a href="register.php">Creaza unul!</a></p>
		</form>
        </form>
	</div>
    <script type="text/javascript">
        $(function () {
            $("#toggle_pwd").click(function () {
                $(this).toggleClass("fa-eye fa-eye-slash");
               var type = $(this).hasClass("fa-eye-slash") ? "text" : "password";
                $("#myInput").attr("type", type);
            });
        });
    </script>
</body>
</html>