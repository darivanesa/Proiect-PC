﻿<?php
include 'config.php';
if(!$conn){
  die("Error: Cannot connect to the database");
}

#ASSIGNING PART
if (isset($_POST['submit'])) {
  $noEmp = (count($_POST)-1)/2;

  for($x=0;$x<$noEmp;$x++){
    $sql = "UPDATE tasks SET employee = " . "'" . $_POST["NAME" . $x] . "'" . " WHERE taskID = " . $_POST["ID" . $x];
    $result = mysqli_query($conn, $sql);
    if (!$result) {
      echo "<script>alert('Woops! Something Wrong Went with assigning task.')</script>";
    }
  }
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js">
    </script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer>
    </script>
    <title>Task List
    </title>
  </head>
  <body style="background-color:#E3ECF8;">
    <div style="height:70px; background-color:white ;  border-bottom: 1px solid grey;">
      <div style=" position:relative; left:5px; top:2px;top:20px">
        <p style='margin-left:260px;font-family: "Calibri",sans-serif;font-size:25px'>Task Dispatcher
        </p>
      </div>
    </div>
    <div style=" position:relative; left:5px; top:2px;top:30px">
      <p style='margin-left:260px;font-family: "Calibri",sans-serif;font-size:35px'> Tasks
      </p>
    </div>
    <div class="col-md-2">
    </div>
    <p style="margin-top:50px;margin-left:260px">Welcome to the Tasks page. Here you can create, view or assign tasks.
    </p>
    <div class="col-md-2">
    </div>
    <a href="create.php">
      <button style='font-family: "Calibri",sans-serif;background-color:#00559A;color:white;padding: 10px 20px;;border-color:#00559A;
                     font-size:15px;border-radius:3px;
                     border: none; box-shadow: 2px 2px 2px grey;
                     '>Create Task
      </button>
    </a>
    <a href="viewtask.php">
      <button style='font-family: "Calibri",sans-serif;margin-left:20px;background-color:#00559A;color:white;padding: 10px 20px;;border-color:#00559A;
                     font-size:15px;border-radius:3px;
                     border: none; box-shadow: 2px 2px 2px grey;'>View Tasks
      </button>
    </a>
    <a href="assign.php">	
      <button style='font-family: "Calibri",sans-serif;margin-left:20px;background-color:#00559A;color:white;padding: 10px 20px;;border-color:#00559A;
                     font-size:15px;border-radius:3px;
                     border: none; box-shadow: 2px 2px 2px grey;'>Assign Tasks
      </button>
    </a>
    <a href="employeeTask.php">	
      <button style='font-family: "Calibri",sans-serif;margin-left:20px;background-color:#00559A;color:white;padding: 10px 20px;;border-color:#00559A;
                     font-size:15px;border-radius:3px;
                     border: none; box-shadow: 2px 2px 2px grey;'>My Tasks
      </button>
    </a>
    <div class="sidenav">
      <a href="logout.php">Logout
      </a>
      <a href="welcome.php">Home
      </a>
      <button class="dropdown-btn">Menu
        <i class="fa fa-caret-down">
        </i>
      </button>
      <div class="dropdown-container">
        <a href="task.php">Task
        </a>
        <a href="skill.php">Skill
        </a>
        <a href="teams.php">Teams
        </a>
        <a href="deadline.php">Deadline
        </a>
      </div>
    </div>
    <script>
      var dropdown = document.getElementsByClassName("dropdown-btn");
      var i;
      for (i = 0; i < dropdown.length; i++) {
        dropdown[i].addEventListener("click", function() {
                                        this.classList.toggle("active");
                                        var dropdownContent = this.nextElementSibling;
                                        if (dropdownContent.style.display === "block") {
                                          dropdownContent.style.display = "none";
                                        }
                                        else {
                                          dropdownContent.style.display = "block";
                                        }
                                      }
                                    );
      }
    </script>
  </body>
</html>
