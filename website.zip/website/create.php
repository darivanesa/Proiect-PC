
<!DOCTYPE html>
<html lang="en">
	<head>


		<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title>Task List</title>
</head>
<body style="background-color:#E3ECF8;">
	


<div style="height:70px; background-color:white ;  border-bottom: 1px solid grey;">
<div style=" position:relative; left:5px; top:2px;top:20px">

<p style='margin-left:260px;font-family: "Calibri",sans-serif;font-size:25px'>Task Dispatcher</p>

</div>
</div>


		
        
       

        <div style="margin-left:550px;margin-top:40px;width:600px;border: 15px grey;
  padding: 50px;background-color:WHITE;border-radius:10px;box-sizing:border-box;height:565px">
  
  
  <h1 style = 'font-size: 30px;margin-top:-10px;font-family: "Calibri",sans-serif;'>Create Task</h1>
         <form action="insertTask.php" id="createTask" method="post">

<br>
<label for="taskName" style = 'font-family: "Calibri",sans-serif; font-size:15px'>Task Name:</label>
               <input type="text" style="border-radius:5px;border: solid ;border-width:thin; background-color: white;" name="taskName" id="taskName">
  <br><br>
  <label for="description" style = 'font-family: "Calibri",sans-serif; font-size:15px'>Description:</label><br>
  <textarea name="description" id="description" method="post" rows="4" cols="50" style="border-style:thin;border-radius:5px;border: solid ;border-width:thin; background-color: white;" ></textarea>
  <br><br>

  <label for="deadline" style = 'font-family: "Calibri",sans-serif; font-size:15px'>Deadline:</label>
    <input type="date" style="border-radius:5px;border: solid ; background-color: white; border-width:thin;" name="deadline"><br><br>

  <label for="department" style = 'font-family: "Calibri",sans-serif; font-size:15px'>Assign to a department:</label>
<select name="department" id="department" style="border-radius:5px;border: solid ; background-color: white; border-width:thin;">
    <option value="administrare">Administrare</option>
  <option value="support">Support</option>
  <option value="dev">Dev</option></select><br><br>

  
  <label for="priority" style = 'font-family: "Calibri",sans-serif; font-size:15px'>Priority:</label>
<select name="priority" id="priority" style="border-radius:5px;border: solid ; background-color: white; border-width:thin;">
    <option value="low">Low</option>
  <option value="medium">Medium</option>
  <option value="high">High</option></select>
  <br><br>
<label for="skills" style = 'font-family: "Calibri",sans-serif; font-size:15px'>Skills:</label>
 <input type="text" style="border-radius:5px;border: solid ; background-color: white; border-width:thin;" name="skills" id="skills">
</select>
  
  
               
     
            <br><br><br>
 
            <input type="submit" style='font-family: "Calibri",sans-serif;background-color:#00559A;color:white;padding: 5px 10px;;border-color:#00559A;
    
    font-size:15px;border-radius:3px;
    border: none; box-shadow: 2px 2px 2px grey;
    
    ' value="Submit">
         </form>


</div>


	
	  <div class="sidenav">
  <a href="logout.php">Logout</a>
  <a href="welcome.php">Home</a>
  <button class="dropdown-btn">Menu
    <i class="fa fa-caret-down"></i>
  </button>




  <div class="dropdown-container">
    <a href="task.php">Task</a>
    <a href="skill.php">Skill</a>
    <a href="teams.php">Teams</a>
    <a href="deadline.php">Deadline</a>
  </div>
  </div>
  <script>
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;









for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>
</body>
</html>
