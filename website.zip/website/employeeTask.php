

<!DOCTYPE html>
<html lang="en">
	<head>


		<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title>Task List</title>


    <style>


.titlu {


    height:89px;
    background-color: blue;
  
    
    
    
    background: linear-gradient(to bottom, #333, #333 60%, #E3ECF8 100%);
   

}




.mytt {


height:20px;
margin-top:20px;
background-color:E3ECF8 ;




background: E3ECF8;


}


.mytt > div {
  
  text-align:left;
padding: 20px 0;
font-size: 35px;
font-weight:600;
background-color:E3ECF8;
font-family: "Calibri",sans-serif;



}



.titlu > div {
  
    text-align:left;
  padding: 20px 0;
  font-size: 30px;
  font-weight:100;
  background-color:white;
  font-family: "Calibri",sans-serif;
  

  
}


.mytasks > div {
  
  text-align:left;
padding: 20px 0;
font-size: 36px;
font-weight:600;
background-color:white;
font-family: "Calibri",sans-serif;
border-radius:10px;


}



.mytasks {


height:70px;
margin-top:80px;
background-color:#E3ECF8 ;





background: #E3ECF8;


}

.mytasks .search-container {
  float: left;
  background-color:transparent;
  border-width: thin;
  border-color:#ddd;
}


.mytasks .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top:11.5px;


  background: #ddd;
  font-size: 19.5px;
  border: none;
  cursor: pointer;
  border-radius:4px;
}

.mytasks .search-container button:hover {
  background: #ccc;
}


.mytasks input[type=text] {
  padding: 6px;
  margin-top: -10px;
  margin-left:40px;
  font-size: 17px;
  border-style:solid;
  border-width: thin;
  border-color:#ddd;
  border-radius:4px;
  font-family: "Calibri",sans-serif;

}


::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
  color: grey;
  opacity: 1; /* Firefox */
  font-weight:100;
  font-family: "Calibri",sans-serif;


  table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}


.mytasks .info .table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}



}




    </style>


</head>
<body style="background-color:#E3ECF8;">
	


<div class="titlu">
    <div class="col-md-2" style="color:white;">orice</div>
    <div class="col-md-6">Task Dispatcher</div>
    <div class="col-md-2" style="color:white;">orice</div>
    <div class="col-md-2">
        
    
    <button type="button" style="margin-left:-100px;font-size:15px;color: white;padding: 6px 25px; background-color: #00559A;border-radius:3px;
    border: none; box-shadow: 2px 2px 2px grey;">Home
</button></div>
</div>


  <div class="mytt">
    <div class="col-md-2" style="color:#E3ECF8;background:#E3ECF8">orice</div>
    <div class="col-sm-2">My Tasks</div>
    

</div>




  <div class="mytasks">
    <div class="col-md-2" style="background-color:#E3ECF8;color:#E3ECF8;">orice</div>
    <div class="col-sm-8">

    
<table style="width:100%">
  <tr style="padding:20px; text-align:center">
    <th> <div class="search-container">
    <form action="/action_page.php">
      <input type="text" placeholder="Search by name" name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
      
    
    </form>
  </div></th>
    <th>
        

    <div class="select-container">

<form action="/action_page.php">
<select style='font-size:17px; padding: 6px; border-radius:4px; border-style:solid;
border-width: thin;
border-color:#ddd;font-family: "Calibri",sans-serif;font-weight:100;width:175px;'>


  <option value="" disabled selected>Select status</option>
  <option value="open" style='font-family: "Calibri",sans-serif'>Open</option>
  <option value="inProgress" style='font-family: "Calibri",sans-serif'>In Progress</option>
  <option value="solved" style='font-family: "Calibri",sans-serif'>Solved</option>

 
</select>


<select style=' font-size:17px; padding: 6px; border-radius:4px; border-style:solid;
border-width: thin;
border-color:#ddd;font-family: "Calibri",sans-serif;font-weight:100;width:175px;margin-left:40px'>


<option value="" disabled selected>Select priority</option>
<option value="low" style='font-family: "Calibri",sans-serif'>Low</option>
<option value="medium" style='font-family: "Calibri",sans-serif'>Medium</option>
<option value="high" style='font-family: "Calibri",sans-serif'>High</option>


</select>
<input type="submit" value="Submit" style="font-size:18px;margin-left:120px;color: white;padding: 6px 25px; background-color: #00559A;border-radius:3px;
    border: none;">
</form>

    </th>
</tr></table>

<table style="width:100%; padding:6px; font-size:20px;margin-top:30px">
  <tr style="padding:20px; text-align:center; margin-left:20px">
    <th style="margin-left:20px;padding:5px;text-align:center;">Task ID</th>
    <th style="padding:5px;text-align:center;">Task Name</th> 
    <th style="padding:5px;text-align:center;">Status</th>
    <th style="padding:5px;text-align:center;">Priority</th>
    <th style="padding:5px;text-align:center;">Deadline</th>
  </tr>

  

			

  </div>
		

  

			

</div>
		


</div>
 
  <script>
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;









for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}
</script>
</body>
</html>
