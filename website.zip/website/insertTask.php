<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

		// servername => localhost
		// username => root
		// password => empty
		// database name => staff
		$conn = mysqli_connect("localhost", "root", "", "project_pc");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
        
		$taskName = $_REQUEST['taskName'];

       

        $description = $_POST['description'];


		
		$deadline = $_REQUEST['deadline'];
        $department = $_REQUEST['department'];
		$priority= $_REQUEST['priority'];
		$skills = $_REQUEST['skills'];
        
        $date = date('Y-m-d H:i:s');






		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO tasks (`taskName`, `description`, `skills`, `department`, `priority`, `deadline`, `date`) VALUES ('$taskName',
			'$description','$skills','$department','$priority','$deadline','$date')";


//$sql = "INSERT INTO tasks VALUES ('','$taskName',
			//'$description','$skills','','','$department','$priority','','$deadline','$date')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>data stored in a database successfully."
				. " Please browse your localhost php my admin"
				. " to view the updated data</h3>";

			
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>
	</center>
</body>

</html>
