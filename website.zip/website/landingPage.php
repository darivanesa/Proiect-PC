﻿<?php 

include 'config.php';

session_start();

error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<!--     <link rel="preconnect" href="https://fonts.gstatic.com">-->
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@400;500;700&display=swap" rel="stylesheet">
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<title>First Page</title>
</head>
<body>
    <div class="flex-container">
        <div class="flex-item-left">
            <img src="poza1.jpg"  style=" width:75%; margin-left:12.5%; height:90%; " >
         </div>
         <div class="flex-item-right">
            <h1 class="big">Manage your tasks<br>Easier and faster</h1>
            <a href="index.php">
        
                <div class="center" align="center" >
            
				        <button name="submit" class="btn">Login</button>
                
	
                </div>
            
	        </a>
            
        </div>
    </div>
</body>
</html>