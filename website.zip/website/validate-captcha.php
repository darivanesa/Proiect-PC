<?php
if (isset($_POST['submit']) && $POST['g-recaptcha-response'] != " {
    include "config.php"";
    $secret= '6LeHJeIaAAAAAGFRdXInFF_kc0N5Er9EfUI1VlzO';
    $verifyResponse= file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret .  '&response=' . $_POST['g-recaptcha-response']);
    $responseData = json_decode ($verifyResponse);
    if($responseData->succes) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        mysqli_query($conn, "INSERT INTO register(username, email , password, cpassword) VALUES(' " . $_POST['username'] . " ' , ' " . $_POST['email'] . " ' , '" .md5($_POST['password']) . " ' ) ");
        echo "Inregistrarea s-a efectuat cu succes";
    }
    
}