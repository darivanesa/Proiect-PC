<?php 

include 'config.php';
?>
<body>
    <div class="container">
        <?php
            $selector = $_GET["selector"];
            $validator = $_GET["validator"];
        
            if(empty($selector) || empty($validator)){
                echo "Nu v-am putut valida cererea!";
            }else{
                if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
                   ?>
                    
        <form action="reset-pasword.php" method="post">
            <input type="hidden" name= "selector" value="<?php echo $selector; ?>">
            <input type="hidden" name= "validator" value="<?php echo $validator; ?>">
            <input type="password" name="pwd" placeholder="Introduceti o noua parola">
            <input type="password" name="pwd-repeat" placeholder="Confirmati noua parola">
            <button type="submit" name="reser-password-submit">Resetati parola</button>
            
        </form>
        
        
        
        
                <?php
                }
            }
        
       
        ?>
        

    </div>
</body>